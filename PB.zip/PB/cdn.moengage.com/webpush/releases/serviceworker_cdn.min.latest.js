/*! For license information please see serviceworker_cdn.js.LICENSE.txt */
(() => {
    var e = {
            483: (e, t, n) => {
                e.exports = function e(t, n, r) {
                    function o(a, c) {
                        if (!n[a]) {
                            if (!t[a]) {
                                if (i) return i(a, !0);
                                var u = new Error("Cannot find module '" + a + "'");
                                throw u.code = "MODULE_NOT_FOUND", u
                            }
                            u = n[a] = {
                                exports: {}
                            }, t[a][0].call(u.exports, (function(e) {
                                return o(t[a][1][e] || e)
                            }), u, u.exports, e, t, n, r)
                        }
                        return n[a].exports
                    }
                    for (var i = void 0, a = 0; a < r.length; a++) o(r[a]);
                    return o
                }({
                    1: [function(e, t, r) {
                        (function(e) {
                            "use strict";
                            var n, r, o, i, a = e.MutationObserver || e.WebKitMutationObserver,
                                c = a ? (n = 0, a = new a(f), r = e.document.createTextNode(""), a.observe(r, {
                                    characterData: !0
                                }), function() {
                                    r.data = n = ++n % 2
                                }) : e.setImmediate || void 0 === e.MessageChannel ? "document" in e && "onreadystatechange" in e.document.createElement("script") ? function() {
                                    var t = e.document.createElement("script");
                                    t.onreadystatechange = function() {
                                        f(), t.onreadystatechange = null, t.parentNode.removeChild(t), t = null
                                    }, e.document.documentElement.appendChild(t)
                                } : function() {
                                    setTimeout(f, 0)
                                } : ((o = new e.MessageChannel).port1.onmessage = f, function() {
                                    o.port2.postMessage(0)
                                }),
                                u = [];

                            function f() {
                                var e, t;
                                i = !0;
                                for (var n = u.length; n;) {
                                    for (t = u, u = [], e = -1; ++e < n;) t[e]();
                                    n = u.length
                                }
                                i = !1
                            }
                            t.exports = function(e) {
                                1 !== u.push(e) || i || c()
                            }
                        }).call(this, void 0 !== n.g ? n.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {})
                    }, {}],
                    2: [function(e, t, n) {
                        "use strict";
                        var r = e(1);

                        function o() {}
                        var i = {},
                            a = ["REJECTED"],
                            c = ["FULFILLED"],
                            u = ["PENDING"];

                        function f(e) {
                            if ("function" != typeof e) throw new TypeError("resolver must be a function");
                            this.state = u, this.queue = [], this.outcome = void 0, e !== o && v(this, e)
                        }

                        function s(e, t, n) {
                            this.promise = e, "function" == typeof t && (this.onFulfilled = t, this.callFulfilled = this.otherCallFulfilled), "function" == typeof n && (this.onRejected = n, this.callRejected = this.otherCallRejected)
                        }

                        function d(e, t, n) {
                            r((function() {
                                var r;
                                try {
                                    r = t(n)
                                } catch (r) {
                                    return i.reject(e, r)
                                }
                                r === e ? i.reject(e, new TypeError("Cannot resolve promise with itself")) : i.resolve(e, r)
                            }))
                        }

                        function l(e) {
                            var t = e && e.then;
                            if (e && ("object" == typeof e || "function" == typeof e) && "function" == typeof t) return function() {
                                t.apply(e, arguments)
                            }
                        }

                        function v(e, t) {
                            var n = !1;

                            function r(t) {
                                n || (n = !0, i.reject(e, t))
                            }

                            function o(t) {
                                n || (n = !0, i.resolve(e, t))
                            }
                            var a = h((function() {
                                t(o, r)
                            }));
                            "error" === a.status && r(a.value)
                        }

                        function h(e, t) {
                            var n = {};
                            try {
                                n.value = e(t), n.status = "success"
                            } catch (e) {
                                n.status = "error", n.value = e
                            }
                            return n
                        }(t.exports = f).prototype.catch = function(e) {
                            return this.then(null, e)
                        }, f.prototype.then = function(e, t) {
                            if ("function" != typeof e && this.state === c || "function" != typeof t && this.state === a) return this;
                            var n = new this.constructor(o);
                            return this.state !== u ? d(n, this.state === c ? e : t, this.outcome) : this.queue.push(new s(n, e, t)), n
                        }, s.prototype.callFulfilled = function(e) {
                            i.resolve(this.promise, e)
                        }, s.prototype.otherCallFulfilled = function(e) {
                            d(this.promise, this.onFulfilled, e)
                        }, s.prototype.callRejected = function(e) {
                            i.reject(this.promise, e)
                        }, s.prototype.otherCallRejected = function(e) {
                            d(this.promise, this.onRejected, e)
                        }, i.resolve = function(e, t) {
                            var n = h(l, t);
                            if ("error" === n.status) return i.reject(e, n.value);
                            if (n = n.value) v(e, n);
                            else {
                                e.state = c, e.outcome = t;
                                for (var r = -1, o = e.queue.length; ++r < o;) e.queue[r].callFulfilled(t)
                            }
                            return e
                        }, i.reject = function(e, t) {
                            e.state = a, e.outcome = t;
                            for (var n = -1, r = e.queue.length; ++n < r;) e.queue[n].callRejected(t);
                            return e
                        }, f.resolve = function(e) {
                            return e instanceof this ? e : i.resolve(new this(o), e)
                        }, f.reject = function(e) {
                            var t = new this(o);
                            return i.reject(t, e)
                        }, f.all = function(e) {
                            var t = this;
                            if ("[object Array]" !== Object.prototype.toString.call(e)) return this.reject(new TypeError("must be an array"));
                            var n = e.length,
                                r = !1;
                            if (!n) return this.resolve([]);
                            for (var a = new Array(n), c = 0, u = -1, f = new this(o); ++u < n;) ! function(e, o) {
                                t.resolve(e).then((function(e) {
                                    a[o] = e, ++c !== n || r || (r = !0, i.resolve(f, a))
                                }), (function(e) {
                                    r || (r = !0, i.reject(f, e))
                                }))
                            }(e[u], u);
                            return f
                        }, f.race = function(e) {
                            var t = this;
                            if ("[object Array]" !== Object.prototype.toString.call(e)) return this.reject(new TypeError("must be an array"));
                            var n = e.length,
                                r = !1;
                            if (!n) return this.resolve([]);
                            for (var a = -1, c = new this(o); ++a < n;) ! function(e) {
                                t.resolve(e).then((function(e) {
                                    r || (r = !0, i.resolve(c, e))
                                }), (function(e) {
                                    r || (r = !0, i.reject(c, e))
                                }))
                            }(e[a]);
                            return c
                        }
                    }, {
                        1: 1
                    }],
                    3: [function(e, t, r) {
                        (function(t) {
                            "use strict";
                            "function" != typeof t.Promise && (t.Promise = e(2))
                        }).call(this, void 0 !== n.g ? n.g : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {})
                    }, {
                        2: 2
                    }],
                    4: [function(e, t, n) {
                        "use strict";
                        var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                                return typeof e
                            } : function(e) {
                                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                            },
                            o = function() {
                                try {
                                    if ("undefined" != typeof indexedDB) return indexedDB;
                                    if ("undefined" != typeof webkitIndexedDB) return webkitIndexedDB;
                                    if ("undefined" != typeof mozIndexedDB) return mozIndexedDB;
                                    if ("undefined" != typeof OIndexedDB) return OIndexedDB;
                                    if ("undefined" != typeof msIndexedDB) return msIndexedDB
                                } catch (e) {
                                    return
                                }
                            }();

                        function i(e, t) {
                            e = e || [], t = t || {};
                            try {
                                return new Blob(e, t)
                            } catch (o) {
                                if ("TypeError" !== o.name) throw o;
                                for (var n = new("undefined" != typeof BlobBuilder ? BlobBuilder : "undefined" != typeof MSBlobBuilder ? MSBlobBuilder : "undefined" != typeof MozBlobBuilder ? MozBlobBuilder : WebKitBlobBuilder), r = 0; r < e.length; r += 1) n.append(e[r]);
                                return n.getBlob(t.type)
                            }
                        }
                        "undefined" == typeof Promise && e(3);
                        var a = Promise;

                        function c(e, t) {
                            t && e.then((function(e) {
                                t(null, e)
                            }), (function(e) {
                                t(e)
                            }))
                        }

                        function u(e, t, n) {
                            "function" == typeof t && e.then(t), "function" == typeof n && e.catch(n)
                        }

                        function f(e) {
                            return "string" != typeof e && (console.warn(e + " used as a key, but it is not a string."), e = String(e)), e
                        }

                        function s() {
                            if (arguments.length && "function" == typeof arguments[arguments.length - 1]) return arguments[arguments.length - 1]
                        }
                        var d = "local-forage-detect-blob-support",
                            l = void 0,
                            v = {},
                            h = Object.prototype.toString,
                            p = "readonly",
                            m = "readwrite";

                        function y(e) {
                            return "boolean" == typeof l ? a.resolve(l) : (t = e, new a((function(e) {
                                var n = t.transaction(d, m),
                                    r = i([""]);
                                n.objectStore(d).put(r, "key"), n.onabort = function(t) {
                                    t.preventDefault(), t.stopPropagation(), e(!1)
                                }, n.oncomplete = function() {
                                    var t = navigator.userAgent.match(/Chrome\/(\d+)/),
                                        n = navigator.userAgent.match(/Edge\//);
                                    e(n || !t || 43 <= parseInt(t[1], 10))
                                }
                            })).catch((function() {
                                return !1
                            })).then((function(e) {
                                return l = e
                            })));
                            var t
                        }

                        function g(e) {
                            e = v[e.name];
                            var t = {};
                            t.promise = new a((function(e, n) {
                                t.resolve = e, t.reject = n
                            })), e.deferredOperations.push(t), e.dbReady ? e.dbReady = e.dbReady.then((function() {
                                return t.promise
                            })) : e.dbReady = t.promise
                        }

                        function b(e) {
                            return (e = v[e.name].deferredOperations.pop()) && (e.resolve(), e.promise)
                        }

                        function _(e, t) {
                            if (e = v[e.name].deferredOperations.pop()) return e.reject(t), e.promise
                        }

                        function w(e, t) {
                            return new a((function(n, r) {
                                if (v[e.name] = v[e.name] || {
                                        forages: [],
                                        db: null,
                                        dbReady: null,
                                        deferredOperations: []
                                    }, e.db) {
                                    if (!t) return n(e.db);
                                    g(e), e.db.close()
                                }
                                var i = [e.name];
                                t && i.push(e.version);
                                var a = o.open.apply(o, i);
                                t && (a.onupgradeneeded = function(t) {
                                    var n = a.result;
                                    try {
                                        n.createObjectStore(e.storeName), t.oldVersion <= 1 && n.createObjectStore(d)
                                    } catch (n) {
                                        if ("ConstraintError" !== n.name) throw n;
                                        console.warn('The database "' + e.name + '" has been upgraded from version ' + t.oldVersion + " to version " + t.newVersion + ', but the storage "' + e.storeName + '" already exists.')
                                    }
                                }), a.onerror = function(e) {
                                    e.preventDefault(), r(a.error)
                                }, a.onsuccess = function() {
                                    n(a.result), b(e)
                                }
                            }))
                        }

                        function I(e) {
                            return w(e, !1)
                        }

                        function E(e) {
                            return w(e, !0)
                        }

                        function S(e, t) {
                            if (!e.db) return 1;
                            var n = !e.db.objectStoreNames.contains(e.storeName),
                                r = e.version < e.db.version,
                                o = e.version > e.db.version;
                            return r && (e.version !== t && console.warn('The database "' + e.name + "\" can't be downgraded from version " + e.db.version + " to version " + e.version + "."), e.version = e.db.version), (o || n) && (!n || (n = e.db.version + 1) > e.version && (e.version = n), 1)
                        }

                        function N(e) {
                            return i([function(e) {
                                for (var t = e.length, n = new ArrayBuffer(t), r = new Uint8Array(n), o = 0; o < t; o++) r[o] = e.charCodeAt(o);
                                return n
                            }(atob(e.data))], {
                                type: e.type
                            })
                        }

                        function O(e) {
                            return e && e.__local_forage_encoded_blob
                        }

                        function T(e) {
                            var t = this,
                                n = t._initReady().then((function() {
                                    var e = v[t._dbInfo.name];
                                    if (e && e.dbReady) return e.dbReady
                                }));
                            return u(n, e, e), n
                        }

                        function D(e, t, n, r) {
                            void 0 === r && (r = 1);
                            try {
                                var o = e.db.transaction(e.storeName, t);
                                n(null, o)
                            } catch (o) {
                                if (0 < r && (!e.db || "InvalidStateError" === o.name || "NotFoundError" === o.name)) return a.resolve().then((function() {
                                    if (!e.db || "NotFoundError" === o.name && !e.db.objectStoreNames.contains(e.storeName) && e.version <= e.db.version) return e.db && (e.version = e.db.version + 1), E(e)
                                })).then((function() {
                                    return function(e) {
                                        g(e);
                                        for (var t = v[e.name], n = t.forages, r = 0; r < n.length; r++) {
                                            var o = n[r];
                                            o._dbInfo.db && (o._dbInfo.db.close(), o._dbInfo.db = null)
                                        }
                                        return e.db = null, I(e).then((function(t) {
                                            return e.db = t, S(e) ? E(e) : t
                                        })).then((function(r) {
                                            e.db = t.db = r;
                                            for (var o = 0; o < n.length; o++) n[o]._dbInfo.db = r
                                        })).catch((function(t) {
                                            throw _(e, t), t
                                        }))
                                    }(e).then((function() {
                                        D(e, t, n, r - 1)
                                    }))
                                })).catch(n);
                                n(o)
                            }
                        }
                        var j = {
                                _driver: "asyncStorage",
                                _initStorage: function(e) {
                                    var t = this,
                                        n = {
                                            db: null
                                        };
                                    if (e)
                                        for (var r in e) n[r] = e[r];
                                    var o = v[n.name];
                                    o || (o = {
                                        forages: [],
                                        db: null,
                                        dbReady: null,
                                        deferredOperations: []
                                    }, v[n.name] = o), o.forages.push(t), t._initReady || (t._initReady = t.ready, t.ready = T);
                                    var i = [];

                                    function c() {
                                        return a.resolve()
                                    }
                                    for (var u = 0; u < o.forages.length; u++) {
                                        var f = o.forages[u];
                                        f !== t && i.push(f._initReady().catch(c))
                                    }
                                    var s = o.forages.slice(0);
                                    return a.all(i).then((function() {
                                        return n.db = o.db, I(n)
                                    })).then((function(e) {
                                        return n.db = e, S(n, t._defaultConfig.version) ? E(n) : e
                                    })).then((function(e) {
                                        n.db = o.db = e, t._dbInfo = n;
                                        for (var r = 0; r < s.length; r++) {
                                            var i = s[r];
                                            i !== t && (i._dbInfo.db = n.db, i._dbInfo.version = n.version)
                                        }
                                    }))
                                },
                                _support: function() {
                                    try {
                                        if (!o) return !1;
                                        var e = "undefined" != typeof openDatabase && /(Safari|iPhone|iPad|iPod)/.test(navigator.userAgent) && !/Chrome/.test(navigator.userAgent) && !/BlackBerry/.test(navigator.platform),
                                            t = "function" == typeof fetch && -1 !== fetch.toString().indexOf("[native code");
                                        return (!e || t) && "undefined" != typeof indexedDB && "undefined" != typeof IDBKeyRange
                                    } catch (e) {
                                        return !1
                                    }
                                }(),
                                iterate: function(e, t) {
                                    var n = this,
                                        r = new a((function(t, r) {
                                            n.ready().then((function() {
                                                D(n._dbInfo, p, (function(o, i) {
                                                    if (o) return r(o);
                                                    try {
                                                        var a = i.objectStore(n._dbInfo.storeName).openCursor(),
                                                            c = 1;
                                                        a.onsuccess = function() {
                                                            var n, r = a.result;
                                                            r ? (O(n = r.value) && (n = N(n)), void 0 !== (n = e(n, r.key, c++)) ? t(n) : r.continue()) : t()
                                                        }, a.onerror = function() {
                                                            r(a.error)
                                                        }
                                                    } catch (o) {
                                                        r(o)
                                                    }
                                                }))
                                            })).catch(r)
                                        }));
                                    return c(r, t), r
                                },
                                getItem: function(e, t) {
                                    var n = this;
                                    e = f(e);
                                    var r = new a((function(t, r) {
                                        n.ready().then((function() {
                                            D(n._dbInfo, p, (function(o, i) {
                                                if (o) return r(o);
                                                try {
                                                    var a = i.objectStore(n._dbInfo.storeName).get(e);
                                                    a.onsuccess = function() {
                                                        var e = a.result;
                                                        O(e = void 0 === e ? null : e) && (e = N(e)), t(e)
                                                    }, a.onerror = function() {
                                                        r(a.error)
                                                    }
                                                } catch (o) {
                                                    r(o)
                                                }
                                            }))
                                        })).catch(r)
                                    }));
                                    return c(r, t), r
                                },
                                setItem: function(e, t, n) {
                                    var r = this;
                                    e = f(e);
                                    var o = new a((function(n, o) {
                                        var i;
                                        r.ready().then((function() {
                                            return i = r._dbInfo, "[object Blob]" === h.call(t) ? y(i.db).then((function(e) {
                                                return e ? t : (n = t, new a((function(e, t) {
                                                    var r = new FileReader;
                                                    r.onerror = t, r.onloadend = function(t) {
                                                        t = btoa(t.target.result || ""), e({
                                                            __local_forage_encoded_blob: !0,
                                                            data: t,
                                                            type: n.type
                                                        })
                                                    }, r.readAsBinaryString(n)
                                                })));
                                                var n
                                            })) : t
                                        })).then((function(t) {
                                            D(r._dbInfo, m, (function(i, a) {
                                                if (i) return o(i);
                                                try {
                                                    var c = a.objectStore(r._dbInfo.storeName);
                                                    null === t && (t = void 0);
                                                    var u = c.put(t, e);
                                                    a.oncomplete = function() {
                                                        n(t = void 0 === t ? null : t)
                                                    }, a.onabort = a.onerror = function() {
                                                        var e = u.error || u.transaction.error;
                                                        o(e)
                                                    }
                                                } catch (i) {
                                                    o(i)
                                                }
                                            }))
                                        })).catch(o)
                                    }));
                                    return c(o, n), o
                                },
                                removeItem: function(e, t) {
                                    var n = this;
                                    e = f(e);
                                    var r = new a((function(t, r) {
                                        n.ready().then((function() {
                                            D(n._dbInfo, m, (function(o, i) {
                                                if (o) return r(o);
                                                try {
                                                    var a = i.objectStore(n._dbInfo.storeName).delete(e);
                                                    i.oncomplete = function() {
                                                        t()
                                                    }, i.onerror = function() {
                                                        r(a.error)
                                                    }, i.onabort = function() {
                                                        var e = a.error || a.transaction.error;
                                                        r(e)
                                                    }
                                                } catch (o) {
                                                    r(o)
                                                }
                                            }))
                                        })).catch(r)
                                    }));
                                    return c(r, t), r
                                },
                                clear: function(e) {
                                    var t = this,
                                        n = new a((function(e, n) {
                                            t.ready().then((function() {
                                                D(t._dbInfo, m, (function(r, o) {
                                                    if (r) return n(r);
                                                    try {
                                                        var i = o.objectStore(t._dbInfo.storeName).clear();
                                                        o.oncomplete = function() {
                                                            e()
                                                        }, o.onabort = o.onerror = function() {
                                                            var e = i.error || i.transaction.error;
                                                            n(e)
                                                        }
                                                    } catch (r) {
                                                        n(r)
                                                    }
                                                }))
                                            })).catch(n)
                                        }));
                                    return c(n, e), n
                                },
                                length: function(e) {
                                    var t = this,
                                        n = new a((function(e, n) {
                                            t.ready().then((function() {
                                                D(t._dbInfo, p, (function(r, o) {
                                                    if (r) return n(r);
                                                    try {
                                                        var i = o.objectStore(t._dbInfo.storeName).count();
                                                        i.onsuccess = function() {
                                                            e(i.result)
                                                        }, i.onerror = function() {
                                                            n(i.error)
                                                        }
                                                    } catch (r) {
                                                        n(r)
                                                    }
                                                }))
                                            })).catch(n)
                                        }));
                                    return c(n, e), n
                                },
                                key: function(e, t) {
                                    var n = this,
                                        r = new a((function(t, r) {
                                            e < 0 ? t(null) : n.ready().then((function() {
                                                D(n._dbInfo, p, (function(o, i) {
                                                    if (o) return r(o);
                                                    try {
                                                        var a = i.objectStore(n._dbInfo.storeName),
                                                            c = !1,
                                                            u = a.openCursor();
                                                        u.onsuccess = function() {
                                                            var n = u.result;
                                                            n ? 0 === e || c ? t(n.key) : (c = !0, n.advance(e)) : t(null)
                                                        }, u.onerror = function() {
                                                            r(u.error)
                                                        }
                                                    } catch (o) {
                                                        r(o)
                                                    }
                                                }))
                                            })).catch(r)
                                        }));
                                    return c(r, t), r
                                },
                                keys: function(e) {
                                    var t = this,
                                        n = new a((function(e, n) {
                                            t.ready().then((function() {
                                                D(t._dbInfo, p, (function(r, o) {
                                                    if (r) return n(r);
                                                    try {
                                                        var i = o.objectStore(t._dbInfo.storeName).openCursor(),
                                                            a = [];
                                                        i.onsuccess = function() {
                                                            var t = i.result;
                                                            t ? (a.push(t.key), t.continue()) : e(a)
                                                        }, i.onerror = function() {
                                                            n(i.error)
                                                        }
                                                    } catch (r) {
                                                        n(r)
                                                    }
                                                }))
                                            })).catch(n)
                                        }));
                                    return c(n, e), n
                                },
                                dropInstance: function(e, t) {
                                    t = s.apply(this, arguments);
                                    var n, r = this.config();
                                    return (e = "function" != typeof e && e || {}).name || (e.name = e.name || r.name, e.storeName = e.storeName || r.storeName), c(n = e.name ? (n = e.name === r.name && this._dbInfo.db ? a.resolve(this._dbInfo.db) : I(e).then((function(t) {
                                        var n = v[e.name],
                                            r = n.forages;
                                        n.db = t;
                                        for (var o = 0; o < r.length; o++) r[o]._dbInfo.db = t;
                                        return t
                                    })), e.storeName ? n.then((function(t) {
                                        if (t.objectStoreNames.contains(e.storeName)) {
                                            var n = t.version + 1;
                                            g(e);
                                            var r = v[e.name],
                                                i = r.forages;
                                            t.close();
                                            for (var c = 0; c < i.length; c++) {
                                                var u = i[c];
                                                u._dbInfo.db = null, u._dbInfo.version = n
                                            }
                                            return new a((function(t, r) {
                                                var i = o.open(e.name, n);
                                                i.onerror = function(e) {
                                                    i.result.close(), r(e)
                                                }, i.onupgradeneeded = function() {
                                                    i.result.deleteObjectStore(e.storeName)
                                                }, i.onsuccess = function() {
                                                    var e = i.result;
                                                    e.close(), t(e)
                                                }
                                            })).then((function(e) {
                                                r.db = e;
                                                for (var t = 0; t < i.length; t++) {
                                                    var n = i[t];
                                                    n._dbInfo.db = e, b(n._dbInfo)
                                                }
                                            })).catch((function(t) {
                                                throw (_(e, t) || a.resolve()).catch((function() {})), t
                                            }))
                                        }
                                    })) : n.then((function(t) {
                                        g(e);
                                        var n = v[e.name],
                                            r = n.forages;
                                        t.close();
                                        for (var i = 0; i < r.length; i++) r[i]._dbInfo.db = null;
                                        return new a((function(t, n) {
                                            var r = o.deleteDatabase(e.name);
                                            r.onerror = r.onblocked = function(e) {
                                                var t = r.result;
                                                t && t.close(), n(e)
                                            }, r.onsuccess = function() {
                                                var e = r.result;
                                                e && e.close(), t(e)
                                            }
                                        })).then((function(e) {
                                            n.db = e;
                                            for (var t = 0; t < r.length; t++) b(r[t]._dbInfo)
                                        })).catch((function(t) {
                                            throw (_(e, t) || a.resolve()).catch((function() {})), t
                                        }))
                                    }))) : a.reject("Invalid arguments"), t), n
                                }
                            },
                            A = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
                            R = /^~~local_forage_type~([^~]+)~/,
                            C = "__lfsc__:",
                            k = C.length,
                            x = "arbf",
                            B = "blob",
                            P = k + x.length,
                            M = Object.prototype.toString;

                        function L(e) {
                            var t, n, r, o, i = .75 * e.length,
                                a = e.length,
                                c = 0;
                            "=" === e[e.length - 1] && (i--, "=" === e[e.length - 2] && i--), i = new ArrayBuffer(i);
                            for (var u = new Uint8Array(i), f = 0; f < a; f += 4) t = A.indexOf(e[f]), n = A.indexOf(e[f + 1]), r = A.indexOf(e[f + 2]), o = A.indexOf(e[f + 3]), u[c++] = t << 2 | n >> 4, u[c++] = (15 & n) << 4 | r >> 2, u[c++] = (3 & r) << 6 | 63 & o;
                            return i
                        }

                        function U(e) {
                            for (var t = new Uint8Array(e), n = "", r = 0; r < t.length; r += 3) n += A[t[r] >> 2], n += A[(3 & t[r]) << 4 | t[r + 1] >> 4], n += A[(15 & t[r + 1]) << 2 | t[r + 2] >> 6], n += A[63 & t[r + 2]];
                            return t.length % 3 == 2 ? n = n.substring(0, n.length - 1) + "=" : t.length % 3 == 1 && (n = n.substring(0, n.length - 2) + "=="), n
                        }
                        var F = {
                            serialize: function(e, t) {
                                var n = "";
                                if (e && (n = M.call(e)), e && ("[object ArrayBuffer]" === n || e.buffer && "[object ArrayBuffer]" === M.call(e.buffer))) {
                                    var r, o = C;
                                    e instanceof ArrayBuffer ? (r = e, o += x) : (r = e.buffer, "[object Int8Array]" === n ? o += "si08" : "[object Uint8Array]" === n ? o += "ui08" : "[object Uint8ClampedArray]" === n ? o += "uic8" : "[object Int16Array]" === n ? o += "si16" : "[object Uint16Array]" === n ? o += "ur16" : "[object Int32Array]" === n ? o += "si32" : "[object Uint32Array]" === n ? o += "ui32" : "[object Float32Array]" === n ? o += "fl32" : "[object Float64Array]" === n ? o += "fl64" : t(new Error("Failed to get type for BinaryArray"))), t(o + U(r))
                                } else if ("[object Blob]" === n)(n = new FileReader).onload = function() {
                                    var n = "~~local_forage_type~" + e.type + "~" + U(this.result);
                                    t(C + B + n)
                                }, n.readAsArrayBuffer(e);
                                else try {
                                    t(JSON.stringify(e))
                                } catch (n) {
                                    console.error("Couldn't convert value into a JSON string: ", e), t(null, n)
                                }
                            },
                            deserialize: function(e) {
                                if (e.substring(0, k) !== C) return JSON.parse(e);
                                var t, n = e.substring(P),
                                    r = e.substring(k, P);
                                r === B && R.test(n) && (t = (e = n.match(R))[1], n = n.substring(e[0].length));
                                var o = L(n);
                                switch (r) {
                                    case x:
                                        return o;
                                    case B:
                                        return i([o], {
                                            type: t
                                        });
                                    case "si08":
                                        return new Int8Array(o);
                                    case "ui08":
                                        return new Uint8Array(o);
                                    case "uic8":
                                        return new Uint8ClampedArray(o);
                                    case "si16":
                                        return new Int16Array(o);
                                    case "ur16":
                                        return new Uint16Array(o);
                                    case "si32":
                                        return new Int32Array(o);
                                    case "ui32":
                                        return new Uint32Array(o);
                                    case "fl32":
                                        return new Float32Array(o);
                                    case "fl64":
                                        return new Float64Array(o);
                                    default:
                                        throw new Error("Unkown type: " + r)
                                }
                            },
                            stringToBuffer: L,
                            bufferToString: U
                        };

                        function W(e, t, n, r) {
                            e.executeSql("CREATE TABLE IF NOT EXISTS " + t.storeName + " (id INTEGER PRIMARY KEY, key unique, value)", [], n, r)
                        }

                        function q(e, t, n, r, o, i) {
                            e.executeSql(n, r, o, (function(e, a) {
                                a.code === a.SYNTAX_ERR ? e.executeSql("SELECT name FROM sqlite_master WHERE type='table' AND name = ?", [t.storeName], (function(e, c) {
                                    c.rows.length ? i(e, a) : W(e, t, (function() {
                                        e.executeSql(n, r, o, i)
                                    }), i)
                                }), i) : i(e, a)
                            }), i)
                        }

                        function z(e, t, n, r) {
                            var o = this;
                            e = f(e);
                            var i = new a((function(i, a) {
                                o.ready().then((function() {
                                    var c = t = void 0 === t ? null : t,
                                        u = o._dbInfo;
                                    u.serializer.serialize(t, (function(t, f) {
                                        f ? a(f) : u.db.transaction((function(n) {
                                            q(n, u, "INSERT OR REPLACE INTO " + u.storeName + " (key, value) VALUES (?, ?)", [e, t], (function() {
                                                i(c)
                                            }), (function(e, t) {
                                                a(t)
                                            }))
                                        }), (function(t) {
                                            t.code === t.QUOTA_ERR && (0 < r ? i(z.apply(o, [e, c, n, r - 1])) : a(t))
                                        }))
                                    }))
                                })).catch(a)
                            }));
                            return c(i, n), i
                        }
                        var V = {
                            _driver: "webSQLStorage",
                            _initStorage: function(e) {
                                var t = this,
                                    n = {
                                        db: null
                                    };
                                if (e)
                                    for (var r in e) n[r] = "string" != typeof e[r] ? e[r].toString() : e[r];
                                var o = new a((function(e, r) {
                                    try {
                                        n.db = openDatabase(n.name, String(n.version), n.description, n.size)
                                    } catch (e) {
                                        return r(e)
                                    }
                                    n.db.transaction((function(o) {
                                        W(o, n, (function() {
                                            t._dbInfo = n, e()
                                        }), (function(e, t) {
                                            r(t)
                                        }))
                                    }), r)
                                }));
                                return n.serializer = F, o
                            },
                            _support: "function" == typeof openDatabase,
                            iterate: function(e, t) {
                                var n = this,
                                    r = new a((function(t, r) {
                                        n.ready().then((function() {
                                            var o = n._dbInfo;
                                            o.db.transaction((function(n) {
                                                q(n, o, "SELECT * FROM " + o.storeName, [], (function(n, r) {
                                                    for (var i = r.rows, a = i.length, c = 0; c < a; c++) {
                                                        var u = i.item(c),
                                                            f = (f = u.value) && o.serializer.deserialize(f);
                                                        if (void 0 !== (f = e(f, u.key, c + 1))) return void t(f)
                                                    }
                                                    t()
                                                }), (function(e, t) {
                                                    r(t)
                                                }))
                                            }))
                                        })).catch(r)
                                    }));
                                return c(r, t), r
                            },
                            getItem: function(e, t) {
                                var n = this;
                                e = f(e);
                                var r = new a((function(t, r) {
                                    n.ready().then((function() {
                                        var o = n._dbInfo;
                                        o.db.transaction((function(n) {
                                            q(n, o, "SELECT * FROM " + o.storeName + " WHERE key = ? LIMIT 1", [e], (function(e, n) {
                                                n = (n = n.rows.length ? n.rows.item(0).value : null) && o.serializer.deserialize(n), t(n)
                                            }), (function(e, t) {
                                                r(t)
                                            }))
                                        }))
                                    })).catch(r)
                                }));
                                return c(r, t), r
                            },
                            setItem: function(e, t, n) {
                                return z.apply(this, [e, t, n, 1])
                            },
                            removeItem: function(e, t) {
                                var n = this;
                                e = f(e);
                                var r = new a((function(t, r) {
                                    n.ready().then((function() {
                                        var o = n._dbInfo;
                                        o.db.transaction((function(n) {
                                            q(n, o, "DELETE FROM " + o.storeName + " WHERE key = ?", [e], (function() {
                                                t()
                                            }), (function(e, t) {
                                                r(t)
                                            }))
                                        }))
                                    })).catch(r)
                                }));
                                return c(r, t), r
                            },
                            clear: function(e) {
                                var t = this,
                                    n = new a((function(e, n) {
                                        t.ready().then((function() {
                                            var r = t._dbInfo;
                                            r.db.transaction((function(t) {
                                                q(t, r, "DELETE FROM " + r.storeName, [], (function() {
                                                    e()
                                                }), (function(e, t) {
                                                    n(t)
                                                }))
                                            }))
                                        })).catch(n)
                                    }));
                                return c(n, e), n
                            },
                            length: function(e) {
                                var t = this,
                                    n = new a((function(e, n) {
                                        t.ready().then((function() {
                                            var r = t._dbInfo;
                                            r.db.transaction((function(t) {
                                                q(t, r, "SELECT COUNT(key) as c FROM " + r.storeName, [], (function(t, n) {
                                                    n = n.rows.item(0).c, e(n)
                                                }), (function(e, t) {
                                                    n(t)
                                                }))
                                            }))
                                        })).catch(n)
                                    }));
                                return c(n, e), n
                            },
                            key: function(e, t) {
                                var n = this,
                                    r = new a((function(t, r) {
                                        n.ready().then((function() {
                                            var o = n._dbInfo;
                                            o.db.transaction((function(n) {
                                                q(n, o, "SELECT key FROM " + o.storeName + " WHERE id = ? LIMIT 1", [e + 1], (function(e, n) {
                                                    n = n.rows.length ? n.rows.item(0).key : null, t(n)
                                                }), (function(e, t) {
                                                    r(t)
                                                }))
                                            }))
                                        })).catch(r)
                                    }));
                                return c(r, t), r
                            },
                            keys: function(e) {
                                var t = this,
                                    n = new a((function(e, n) {
                                        t.ready().then((function() {
                                            var r = t._dbInfo;
                                            r.db.transaction((function(t) {
                                                q(t, r, "SELECT key FROM " + r.storeName, [], (function(t, n) {
                                                    for (var r = [], o = 0; o < n.rows.length; o++) r.push(n.rows.item(o).key);
                                                    e(r)
                                                }), (function(e, t) {
                                                    n(t)
                                                }))
                                            }))
                                        })).catch(n)
                                    }));
                                return c(n, e), n
                            },
                            dropInstance: function(e, t) {
                                t = s.apply(this, arguments);
                                var n = this.config();
                                (e = "function" != typeof e && e || {}).name || (e.name = e.name || n.name, e.storeName = e.storeName || n.storeName);
                                var r = this,
                                    o = e.name ? new a((function(t) {
                                        var o, i = e.name === n.name ? r._dbInfo.db : openDatabase(e.name, "", "", 0);
                                        e.storeName ? t({
                                            db: i,
                                            storeNames: [e.storeName]
                                        }) : t((o = i, new a((function(e, t) {
                                            o.transaction((function(n) {
                                                n.executeSql("SELECT name FROM sqlite_master WHERE type='table' AND name <> '__WebKitDatabaseInfoTable__'", [], (function(t, n) {
                                                    for (var r = [], i = 0; i < n.rows.length; i++) r.push(n.rows.item(i).name);
                                                    e({
                                                        db: o,
                                                        storeNames: r
                                                    })
                                                }), (function(e, n) {
                                                    t(n)
                                                }))
                                            }), (function(e) {
                                                t(e)
                                            }))
                                        }))))
                                    })).then((function(e) {
                                        return new a((function(t, n) {
                                            e.db.transaction((function(r) {
                                                for (var o = [], i = 0, c = e.storeNames.length; i < c; i++) o.push(function(e) {
                                                    return new a((function(t, n) {
                                                        r.executeSql("DROP TABLE IF EXISTS " + e, [], (function() {
                                                            t()
                                                        }), (function(e, t) {
                                                            n(t)
                                                        }))
                                                    }))
                                                }(e.storeNames[i]));
                                                a.all(o).then((function() {
                                                    t()
                                                })).catch((function(e) {
                                                    n(e)
                                                }))
                                            }), (function(e) {
                                                n(e)
                                            }))
                                        }))
                                    })) : a.reject("Invalid arguments");
                                return c(o, t), o
                            }
                        };

                        function H(e, t) {
                            var n = e.name + "/";
                            return e.storeName !== t.storeName && (n += e.storeName + "/"), n
                        }

                        function X(e, t) {
                            for (var n, r, o = e.length, i = 0; i < o;) {
                                if ((n = e[i]) === (r = t) || "number" == typeof n && "number" == typeof r && isNaN(n) && isNaN(r)) return 1;
                                i++
                            }
                        }
                        e = {
                            _driver: "localStorageWrapper",
                            _initStorage: function(e) {
                                var t = {};
                                if (e)
                                    for (var n in e) t[n] = e[n];
                                return t.keyPrefix = H(e, this._defaultConfig), ! function() {
                                    var e = "_localforage_support_test";
                                    try {
                                        return localStorage.setItem(e, !0), void localStorage.removeItem(e)
                                    } catch (e) {
                                        return 1
                                    }
                                }() || 0 < localStorage.length ? ((this._dbInfo = t).serializer = F, a.resolve()) : a.reject()
                            },
                            _support: function() {
                                try {
                                    return "undefined" != typeof localStorage && "setItem" in localStorage && !!localStorage.setItem
                                } catch (e) {
                                    return !1
                                }
                            }(),
                            iterate: function(e, t) {
                                var n = this,
                                    r = n.ready().then((function() {
                                        for (var t = n._dbInfo, r = t.keyPrefix, o = r.length, i = localStorage.length, a = 1, c = 0; c < i; c++) {
                                            var u = localStorage.key(c);
                                            if (0 === u.indexOf(r)) {
                                                var f = (f = localStorage.getItem(u)) && t.serializer.deserialize(f);
                                                if (void 0 !== (f = e(f, u.substring(o), a++))) return f
                                            }
                                        }
                                    }));
                                return c(r, t), r
                            },
                            getItem: function(e, t) {
                                var n = this;
                                e = f(e);
                                var r = n.ready().then((function() {
                                    var t = n._dbInfo,
                                        r = localStorage.getItem(t.keyPrefix + e);
                                    return r && t.serializer.deserialize(r)
                                }));
                                return c(r, t), r
                            },
                            setItem: function(e, t, n) {
                                var r = this;
                                e = f(e);
                                var o = r.ready().then((function() {
                                    var n = t = void 0 === t ? null : t;
                                    return new a((function(o, i) {
                                        var a = r._dbInfo;
                                        a.serializer.serialize(t, (function(t, r) {
                                            if (r) i(r);
                                            else try {
                                                localStorage.setItem(a.keyPrefix + e, t), o(n)
                                            } catch (t) {
                                                "QuotaExceededError" !== t.name && "NS_ERROR_DOM_QUOTA_REACHED" !== t.name || i(t), i(t)
                                            }
                                        }))
                                    }))
                                }));
                                return c(o, n), o
                            },
                            removeItem: function(e, t) {
                                var n = this;
                                e = f(e);
                                var r = n.ready().then((function() {
                                    var t = n._dbInfo;
                                    localStorage.removeItem(t.keyPrefix + e)
                                }));
                                return c(r, t), r
                            },
                            clear: function(e) {
                                var t = this,
                                    n = t.ready().then((function() {
                                        for (var e = t._dbInfo.keyPrefix, n = localStorage.length - 1; 0 <= n; n--) {
                                            var r = localStorage.key(n);
                                            0 === r.indexOf(e) && localStorage.removeItem(r)
                                        }
                                    }));
                                return c(n, e), n
                            },
                            length: function(e) {
                                var t = this.keys().then((function(e) {
                                    return e.length
                                }));
                                return c(t, e), t
                            },
                            key: function(e, t) {
                                var n = this,
                                    r = n.ready().then((function() {
                                        var t, r = n._dbInfo;
                                        try {
                                            t = localStorage.key(e)
                                        } catch (r) {
                                            t = null
                                        }
                                        return t && t.substring(r.keyPrefix.length)
                                    }));
                                return c(r, t), r
                            },
                            keys: function(e) {
                                var t = this,
                                    n = t.ready().then((function() {
                                        for (var e = t._dbInfo, n = localStorage.length, r = [], o = 0; o < n; o++) {
                                            var i = localStorage.key(o);
                                            0 === i.indexOf(e.keyPrefix) && r.push(i.substring(e.keyPrefix.length))
                                        }
                                        return r
                                    }));
                                return c(n, e), n
                            },
                            dropInstance: function(e, t) {
                                t = s.apply(this, arguments), (e = "function" != typeof e && e || {}).name || (r = this.config(), e.name = e.name || r.name, e.storeName = e.storeName || r.storeName);
                                var n = this,
                                    r = e.name ? new a((function(t) {
                                        e.storeName ? t(H(e, n._defaultConfig)) : t(e.name + "/")
                                    })).then((function(e) {
                                        for (var t = localStorage.length - 1; 0 <= t; t--) {
                                            var n = localStorage.key(t);
                                            0 === n.indexOf(e) && localStorage.removeItem(n)
                                        }
                                    })) : a.reject("Invalid arguments");
                                return c(r, t), r
                            }
                        };
                        var J = Array.isArray || function(e) {
                                return "[object Array]" === Object.prototype.toString.call(e)
                            },
                            Q = {},
                            K = {},
                            Y = {
                                INDEXEDDB: j,
                                WEBSQL: V,
                                LOCALSTORAGE: e
                            },
                            G = (e = [Y.INDEXEDDB._driver, Y.WEBSQL._driver, Y.LOCALSTORAGE._driver], ["dropInstance"]),
                            $ = ["clear", "getItem", "iterate", "key", "keys", "length", "removeItem", "setItem"].concat(G),
                            Z = {
                                description: "",
                                driver: e.slice(),
                                name: "localforage",
                                size: 4980736,
                                storeName: "keyvaluepairs",
                                version: 1
                            };

                        function ee(e) {
                            for (var t = 1; t < arguments.length; t++) {
                                var n = arguments[t];
                                if (n)
                                    for (var r in n) n.hasOwnProperty(r) && (J(n[r]) ? e[r] = n[r].slice() : e[r] = n[r])
                            }
                            return e
                        }

                        function te(e) {
                            for (var t in function(e, t) {
                                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                                }(this, te), Y) {
                                var n, r;
                                Y.hasOwnProperty(t) && (r = (n = Y[t])._driver, this[t] = r, Q[r] || this.defineDriver(n))
                            }
                            this._defaultConfig = ee({}, Z), this._config = ee({}, this._defaultConfig, e), this._driverSet = null, this._initDriver = null, this._ready = !1, this._dbInfo = null, this._wrapLibraryMethodsWithReady(), this.setDriver(this._config.driver).catch((function() {}))
                        }
                        e = new(te.prototype.config = function(e) {
                            if ("object" !== (void 0 === e ? "undefined" : r(e))) return "string" == typeof e ? this._config[e] : this._config;
                            if (this._ready) return new Error("Can't call config() after localforage has been used.");
                            for (var t in e) {
                                if ("storeName" === t && (e[t] = e[t].replace(/\W/g, "_")), "version" === t && "number" != typeof e[t]) return new Error("Database version must be a number.");
                                this._config[t] = e[t]
                            }
                            return !("driver" in e && e.driver) || this.setDriver(this._config.driver)
                        }, te.prototype.defineDriver = function(e, t, n) {
                            var r = new a((function(t, n) {
                                try {
                                    var r = e._driver,
                                        o = new Error("Custom driver not compliant; see https://mozilla.github.io/localForage/#definedriver");
                                    if (!e._driver) return void n(o);
                                    for (var i = $.concat("_initStorage"), u = 0, f = i.length; u < f; u++) {
                                        var s = i[u];
                                        if ((!X(G, s) || e[s]) && "function" != typeof e[s]) return void n(o)
                                    }! function() {
                                        for (var t = 0, n = G.length; t < n; t++) {
                                            var r = G[t];
                                            e[r] || (e[r] = function(e) {
                                                return function() {
                                                    var t = new Error("Method " + e + " is not implemented by the current driver");
                                                    return c(t = a.reject(t), arguments[arguments.length - 1]), t
                                                }
                                            }(r))
                                        }
                                    }();
                                    var d = function(n) {
                                        Q[r] && console.info("Redefining LocalForage driver: " + r), Q[r] = e, K[r] = n, t()
                                    };
                                    "_support" in e ? e._support && "function" == typeof e._support ? e._support().then(d, n) : d(!!e._support) : d(!0)
                                } catch (o) {
                                    n(o)
                                }
                            }));
                            return u(r, t, n), r
                        }, te.prototype.driver = function() {
                            return this._driver || null
                        }, te.prototype.getDriver = function(e, t, n) {
                            return u(e = Q[e] ? a.resolve(Q[e]) : a.reject(new Error("Driver not found.")), t, n), e
                        }, te.prototype.getSerializer = function(e) {
                            var t = a.resolve(F);
                            return u(t, e), t
                        }, te.prototype.ready = function(e) {
                            var t = this,
                                n = t._driverSet.then((function() {
                                    return null === t._ready && (t._ready = t._initDriver()), t._ready
                                }));
                            return u(n, e, e), n
                        }, te.prototype.setDriver = function(e, t, n) {
                            var r = this;
                            J(e) || (e = [e]);
                            var o = this._getSupportedDrivers(e);

                            function i() {
                                r._config.driver = r.driver()
                            }

                            function c(e) {
                                return r._extend(e), i(), r._ready = r._initStorage(r._config), r._ready
                            }
                            return e = null !== this._driverSet ? this._driverSet.catch((function() {
                                return a.resolve()
                            })) : a.resolve(), this._driverSet = e.then((function() {
                                var e = o[0];
                                return r._dbInfo = null, r._ready = null, r.getDriver(e).then((function(e) {
                                    r._driver = e._driver, i(), r._wrapLibraryMethodsWithReady(), r._initDriver = function(e) {
                                        return function() {
                                            var t = 0;
                                            return function n() {
                                                for (; t < e.length;) {
                                                    var o = e[t];
                                                    return t++, r._dbInfo = null, r._ready = null, r.getDriver(o).then(c).catch(n)
                                                }
                                                i();
                                                var u = new Error("No available storage method found.");
                                                return r._driverSet = a.reject(u), r._driverSet
                                            }()
                                        }
                                    }(o)
                                }))
                            })).catch((function() {
                                i();
                                var e = new Error("No available storage method found.");
                                return r._driverSet = a.reject(e), r._driverSet
                            })), u(this._driverSet, t, n), this._driverSet
                        }, te.prototype.supports = function(e) {
                            return !!K[e]
                        }, te.prototype._extend = function(e) {
                            ee(this, e)
                        }, te.prototype._getSupportedDrivers = function(e) {
                            for (var t = [], n = 0, r = e.length; n < r; n++) {
                                var o = e[n];
                                this.supports(o) && t.push(o)
                            }
                            return t
                        }, te.prototype._wrapLibraryMethodsWithReady = function() {
                            for (var e = 0, t = $.length; e < t; e++) ! function(e, t) {
                                e[t] = function() {
                                    var n = arguments;
                                    return e.ready().then((function() {
                                        return e[t].apply(e, n)
                                    }))
                                }
                            }(this, $[e])
                        }, te.prototype.createInstance = function(e) {
                            return new te(e)
                        }, te), t.exports = e
                    }, {
                        3: 3
                    }]
                }, {}, [4])(4)
            }
        },
        t = {};

    function n(r) {
        var o = t[r];
        return void 0 !== o || (o = t[r] = {
            exports: {}
        }, e[r](o, o.exports, n)), o.exports
    }
    n.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return n.d(t, {
            a: t
        }), t
    }, n.d = (e, t) => {
        for (var r in t) n.o(t, r) && !n.o(e, r) && Object.defineProperty(e, r, {
            enumerable: !0,
            get: t[r]
        })
    }, n.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || new Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), n.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), n.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    };
    var r = {};
    (() => {
        "use strict";
        n.r(r);
        var e = n(483),
            t = n.n(e);
        (function(e) {
            var n, r, o, i = {
                    env: "sdk-01.moengage.com",
                    get: function() {
                        return "https://" + i.env
                    },
                    set: function(e) {
                        i.env = e
                    }
                },
                a = function() {
                    return i.get() + "/v2/sdk/report/"
                },
                c = "https://fcm.googleapis.com/fcm/send/",
                u = "https://updates.push.services.mozilla.com/wpush/v2/",
                f = "https://wns2-pn1p.notify.windows.com/w/?token=",
                s = "https://web.push.apple.com/";

            function d(t) {
                t.waitUntil(e.skipWaiting())
            }

            function l(t) {
                t.waitUntil(e.clients.claim())
            }

            function v(e) {
                e.data && (e.data.data && e.data.data.app_id ? (n.setItem("reportParams", e.data), e.data.data.environment && i.set(e.data.data.environment)) : e.data.cartToken && e.waitUntil(n.getItem("reportParams").then((function(e) {
                    e.data.environment && i.set(e.data.environment)
                })).then((function() {
                    return t = e.data, new Promise(((e, r) => {
                        let o = 5;
                        const i = setInterval((async () => {
                            try {
                                var r = await cookieStore.get("cart");
                                if (r && r.value) {
                                    clearInterval(i);
                                    const o = {
                                            h: "",
                                            meta: {
                                                bid: _()
                                            },
                                            url: t.url
                                        },
                                        c = {
                                            cart_token: r.value
                                        };
                                    var a = t.moe_user_id;
                                    a && (o.identifiers = {
                                        moe_user_id: a
                                    }, c.USER_ATTRIBUTE_UNIQUE_ID = a), b("EVENT_ACTION_USER_ATTRIBUTE", {
                                        cart_token: r.value
                                    }, 0, o), n.setItem("shopify_cookie_attr", c), e()
                                }
                                o--, o <= 0 && (clearInterval(i), e())
                            } catch (r) {
                                clearInterval(i), console.error("Unable to fetch the cart cookie: " + r), e()
                            }
                        }), 1e3)
                    }));
                    var t
                }))))
            }

            function h(t) {
                var o;
                e.Notification && "granted" === e.Notification.permission && (r.iterate((function(e, t) {
                    (Date.now() - e.timestamp) / 864e5 > 28 && r.removeItem(t)
                })), t.waitUntil(n.getItem("reportParams").then((function(e) {
                    e && e.data && (e.data, e.data.environment && i.set(e.data.environment))
                })).then((function() {
                    try {
                        var e = t.data.json();
                        if (e) return e
                    } catch (e) {
                        console.error("payload not received or has some errors in Moengage Push")
                    }
                })).then((async function(t) {
                    var n, i, a, c = t.payload;
                    if (c && c.moe_cid_attr) {
                        if (t.cid) {
                            if (o = t.cid, n = o, await r.length().then((e => {
                                    if (0 === e) throw new Error("Existing campaign not present in indexedDB");
                                    return r.iterate((function(e, t) {
                                        if (n === t) return !0
                                    })).then((e => e))
                                })).catch((() => !1))) throw new Error(`The campaign ${o} has already been executed.`);
                            var u = {
                                cid: o
                            };
                            c && (u = {
                                cid: o,
                                title: c.title,
                                message: c.message,
                                actions: c.actions,
                                image: c.image,
                                moe_cid_attr: c.moe_cid_attr,
                                timestamp: Date.now()
                            }), r.setItem(o, u)
                        }
                        if (!c || !c.title || !c.message) return b("MOE_NO_PAYLOAD_WEB", {
                            cid: t.cid
                        }), console.error("Moengage - Web Push payload error"), y("Welcome", {
                            body: "Something unexpected happened",
                            requireInteraction: !1
                        });
                        try {
                            i = c.moe_cid_attr.moe_campaign_id, a = c.moe_cid_attr.moe_campaign_name
                        } catch (t) {
                            throw new Error("cannot get campaign ID or campaign Name.")
                        }
                        return b("NOTIFICATION_RECEIVED_WEB_MOE", {
                            cid: o,
                            moe_campaign_id: i,
                            moe_campaign_name: a,
                            ...c.moe_cid_attr
                        }), t = {
                            body: c.message,
                            icon: c.icon,
                            tag: t.cid || "moe-id",
                            badge: c.badge,
                            data: {
                                url: c.urlToOpen,
                                actions: c.actions,
                                cid: o
                            },
                            requireInteraction: c && !JSON.parse(t.payload.reqInteract) || !1,
                            actions: c.actions,
                            image: c.image
                        }, c = c.title, e.registration.showNotification(c, t)
                    }
                })).catch((function(e) {
                    return console.error("Moengage Service Worker Error - ", e), y("Welcome", {
                        body: "Something unexpected happened",
                        requireInteraction: !1
                    })
                }))))
            }

            function p(e) {
                var t, o = e.notification.data;
                e.notification.close();
                var a = Promise.resolve();
                o && ("0" === e.action && o.actions && o.actions instanceof Array && 0 < o.actions.length && o.actions[0].url ? (a = clients.openWindow(o.actions[0].url), t = o.actions[0].title) : "1" === e.action && o.actions && o.actions instanceof Array && 1 < o.actions.length && o.actions[1].url ? (a = clients.openWindow(o.actions[1].url), t = o.actions[1].title) : o.url && (a = clients.openWindow(o.url), t = o.title));
                var c = new Promise((function(e) {
                    r.iterate((function(e, n) {
                        if (n == o.cid) {
                            var r, i;
                            try {
                                r = e.moe_cid_attr.moe_campaign_id, i = e.moe_cid_attr.moe_campaign_name
                            } catch (e) {
                                throw new Error(e)
                            }
                            return b("NOTIFICATION_CLICKED_WEB_MOE", {
                                cid: e.cid,
                                button: t || void 0,
                                moe_campaign_id: r,
                                moe_campaign_name: i,
                                ...e.moe_cid_attr
                            }), n
                        }
                    })).then((function(t) {
                        console.info("Web Push Campaign clicked: ", t), e()
                    }))
                }));
                e.waitUntil(n.getItem("reportParams").then((function(e) {
                    e.data.environment && i.set(e.data.environment)
                })).then((function() {
                    return Promise.all([a, c])
                })))
            }

            function m(e) {
                var t = e.notification.data;
                r.iterate((function(e, n) {
                    if (n == t.cid) return n
                })).then((function(e) {
                    console.info("Web Push Campaign closed: ", e)
                }))
            }

            function y(t, n) {
                return e.registration.showNotification(t, n).then((function() {
                    setTimeout(g, 2e3)
                }))
            }

            function g() {
                e.registration.getNotifications().then((function(e) {
                    for (var t = 0; t < e.length; ++t) e[t].close()
                }))
            }

            function b(t, r, o, i = {}) {
                n.getItem("reportParams").then((function(n) {
                    var o = n.data;
                    o.sdk_ver = "2.45.3", o.device_ts = (n = new Date, Number(Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate(), n.getUTCHours(), n.getUTCMinutes(), n.getUTCSeconds(), n.getUTCMilliseconds()))), delete i.h, e.registration.pushManager.getSubscription().then((function(e) {
                        e && (n = 0 === (e = (n = e).endpoint).indexOf(c) ? e.replace(c, "") : 0 === e.indexOf(u) ? e.replace(u, "") : 0 === e.indexOf(s) ? e.replace(s, "") : 0 === e.indexOf(f) ? e.replace(f, "") : n.subscriptionId) ? o.push_id = n : delete o.push_id, delete o.os_platform, o.app_ver = o.app_ver.toString();
                        var n = {
                            query_params: o,
                            meta: {
                                bid: _(),
                                request_time: (new Date).toISOString()
                            },
                            viewsCount: 1,
                            viewsInfo: [{
                                EVENT_ACTION: t,
                                EVENT_ATTRS: r,
                                EVENT_G_TIME: (new Date).getTime().toString(),
                                EVENT_L_TIME: function() {
                                    const e = new Date;
                                    return `${e.getDate()}:${e.getMonth()+1}:${e.getFullYear()}:${e.getHours()}:${e.getMinutes()}:` + e.getSeconds()
                                }()
                            }],
                            ...i
                        };
                        fetch(a() + o.app_id, {
                            method: "POST",
                            body: JSON.stringify(n)
                        }).then((function(e) {
                            return e.json()
                        }))
                    }))
                }))
            }

            function _() {
                return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, (e => (e ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> e / 4).toString(16)))
            }

            function w(e) {
                "moe_offline_data_sync" === e.tag && e.waitUntil(I().then((function(e) {})))
            }

            function I() {
                return new Promise((function(e, t) {
                    Promise.all([o.getItem("requestMetaData").then((function(e) {
                        return e
                    })), new Promise((function(e) {
                        return o.keys().then((function(e) {
                            return e
                        })).then((function(t) {
                            return new Promise((function() {
                                var n = [];
                                t.map((function(e) {
                                    "requestMetaData" !== e && n.push(o.getItem(e))
                                })), Promise.all(n).then((function(t) {
                                    e(t)
                                }))
                            }))
                        }))
                    }))]).then((function(e) {
                        if (e[0] && e[1]) {
                            var t = e[0];
                            return e = function e(t) {
                                return t.reduce((function(t, n) {
                                    return Array.isArray(n) ? t.concat(e(n)) : t.concat(n)
                                }), [])
                            }(e[1]), t.viewsInfo = e, t.viewsCount = e.length, t
                        }
                    })).then((function(t) {
                        return t ? fetch(a() + t.query_params.app_id, {
                            method: "POST",
                            body: JSON.stringify(t)
                        }).then((function(e) {
                            return e.json()
                        })).then((function(t) {
                            if ("success" !== t.status) throw new Error;
                            return o.clear().then((function() {
                                e("successfully replayed failed requests and cleared db")
                            }))
                        })) : void e("No pending requests to replay")
                    })).catch((function(e) {
                        t("Replaying failed.", e)
                    }))
                }))
            }
            return {
                init: async function() {
                    e.addEventListener("install", d), e.addEventListener("activate", l), e.addEventListener("message", v), e.addEventListener("push", h), e.addEventListener("notificationclick", p), e.addEventListener("notificationclose", m), e.addEventListener("sync", w), await new Promise(((e, i) => {
                        n = t().createInstance({
                            driver: [t().INDEXEDDB],
                            name: "moe_database",
                            storeName: "moe_data"
                        }), r = t().createInstance({
                            driver: [t().INDEXEDDB],
                            name: "moe_database",
                            storeName: "moe_backup"
                        }), o = t().createInstance({
                            driver: [t().INDEXEDDB],
                            name: "moe_database",
                            storeName: "offline_data"
                        }), Promise.all([n.ready(), r.ready(), o.ready()]).then(e())
                    })), n.getItem("reportParams").then((function(e) {
                        e && e.data && ("allowed" === e.data.isBatchingEnabled || !0 === e.data.isBatchingEnabled) && I().then((function(e) {
                            console.log(e)
                        })).catch((function(e) {
                            console.log(e)
                        }))
                    }))
                }
            }
        })(self).init(), self.addEventListener("fetch", (e => {}))
    })()
})();